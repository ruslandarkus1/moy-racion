# Local application contract

## Scope and evidence

The user's request is a free local version of the referenced diet questionnaire. The published nine initial steps and thirteen further configuration positions are preserved through their downloaded client. The service redirects to a paid subscription after the questionnaire; that private backend and its content were unavailable. The user confirmed they have neither source code nor paid access and requested a free local implementation, then more recipes. Local menu generation and the 253-recipe library are independently implemented.

## Canonical UI Map

| Capability | Canonical owner | Source of truth | Allowed variants | Verification |
| --- | --- | --- | --- | --- |
| Select/Listbox | Native select in settingsView | DESIGN.md and app.js | Native platform popup | Browser keyboard and open popup |
| Form | settings-form submit handler | engine normalizeProfile and buildPlan | Settings edit | Invalid and valid save |
| Scrollbar | accessibility.css | DESIGN.md | Document, dialog | Narrow screen, long dialog |
| Toast | notify and #status | app.js | Neutral status | Save and replacement |
| CRUD | local plan storage and backup workflow | engine and app.js | Create week, replace, undo, restore backup | engine tests and browser report |
| Table | .basket-table and .basket-table-wrap | economy.js + economyView | Finite 13 stores, local horizontal scroll | 390px browser and fairness tests |
| Dialog | openDialog/closeDialog | app.js and native dialog | Recipe, replacement, backup confirmation | Escape, focus restoration |

No searchable data table, row selection or date picker is present. Recipe search is local and synchronous, with IME composition handling and a clear action. Recipe paging is explicit and bounded.

## Privacy and runtime

The PowerShell server binds to 127.0.0.1 only. Host and Origin are checked. CSP disallows remote connections, frames and remote assets. Payments and subscription verification do not exist in the local edition; no paid status is simulated. Tracking is disabled. Questionnaire progress remains in localStorage; profile, menus, favorite recipes, ingredient prices and shopping checks use local_* keys. Export/restore copies data through a user-selected local file.

START.cmd starts an existing Windows PowerShell runtime, launches a hidden loopback server and opens the local URL. STOP.cmd uses the local per-process control token to stop only this application's server. No installation, registry setting, firewall rule, public port or paid API is required.

## Workflows

- Finishing the public-style questionnaire opens /menu.html before any payment navigation.
- Both sexes can complete the complete local questionnaire.
- A new week creates and saves a plan. Returning to a saved week restores it.
- Replacing a meal preserves its personal calorie allocation, reapplies restrictions and updates family ingredients and shopping costs. Undo restores the previous plan.
- Repeat limits apply to a recipe across the whole week, rather than separately to lunch and dinner.
- Settings save validates fields and plan feasibility before committing, preserving the input on errors. Save returns to menu and announces success.
- Backup restore validates recipe references and constraints, asks for confirmation before replacing current data, and preserves an explicit cancel action.
- Missing recipes or contradictory restrictions produce actionable empty states. Exclusions never fall back to unrestricted recipes.
- Planner totals use editable estimates per kilogram. Explicitly applied catalog prices become user estimates; whole-package prices and conditions remain in the separate offers section.

## Kazan catalog prices and promotions

The user requested all 13 listed chains in Kazan. offers.js owns freshness, matching and package rounding. collect_offers.py discovers public Kazan catalogs from the Proshoper city index. This is catalog information, not direct POS or complete branch inventory. Missing sources are explicit; no invented prices fill gaps. Products match by category; exact composition, processing and allergy warnings require user review.

Deals and recipe footers share offerCard and offersNotice. Campaigns expire at midnight Europe/Moscow; observations over 36 hours old are hidden. Missing dates, invalid prices, wrong cities and unsafe source URLs are rejected. Package counts round up only with explicit gram weights. Search/store filters are transient local state, paginate by 12, reset page on change, preserve focus and provide clear/retry/empty states. Native store select reuses the settings owner.

The Pages workflow collects catalogs every six hours before deployment; GitHub may delay runs. Refresh downloads the latest published feed, not shops directly. Offline observations obey the same expiry limits. The standalone local edition retains a snapshot until its updater is run. No personal profile is sent. Applying a price explicitly edits the existing per-kilogram estimate without changing recipe ingredients or portions.
- Automatic weight-loss menu generation is not provided for minors or pregnancy/GV profiles; the recipe library remains available. This is a limitation of this local implementation, not a claim about the source service.

## Data and consistency

engine.js owns normalization, nutrient arithmetic, food compatibility, portions, dates, recipe repetition, menu creation and replacement. foods.json owns ingredient values and recipe instructions. All recipe surfaces use the same dataset and compatibility predicate. The original public recipe-card calorie labels are retained inside the questionnaire; the independently written local recipes calculate their own approximate values from their ingredients.

## Verification

tests/engine.test.mjs verifies calculations, exclusions, diets, appliances, limits, family portions, drinks, replacement, shopping totals and failure cases. docs/runtime-verification.md records browser and server checks. design-qa.md records source-to-local visual comparison and its scope.

## Basket comparison and promotion planning

economy.js owns conservative product matching, whole-package basket costs, fair comparison and promotion recipe weights. Single-chain partial sums cover different products and are never ranked as complete baskets. Pair comparisons use their own shared ingredient subsets and full-package quantities; split shopping minimizes whole-package cost for each ingredient. Unknown prices, units, fat variants and bone-in poultry are excluded from automatic comparison. Missing products are explicit and never treated as free. Transport/delivery and pantry stock are outside the calculation.

The per-product price matrix uses one semantic table with caption and scoped headings; its wrapper owns horizontal scrolling on narrow screens. It needs no paging. Store checkboxes preserve focus and are local to this device. The shared offers freshness policy applies to comparison, export and preview.

Promotion planning changes candidate ranking only after existing diet/allergy/exclusion/appliance/portion/repetition constraints. A preview must improve promotion coverage score compared with the current plan; it never asserts guaranteed full-basket savings. Applying is a deliberate second action, rejects changed plan/profile/stores or expired catalog data, validates the candidate, saves only the selected week and supports the existing Undo. Cancelling leaves the original plan intact. No product substitution or restriction relaxation is automatic.

## Return to store selection

The shared planner header includes «Сменить магазин», linking to /racion?restart=1. Settings also includes «В начало анкеты». The bridge consumes this explicit parameter before questionnaire initialization and sets only the saved screen to STORES (2), preserving answers, existing menus and favorites. The transient parameter is removed, so later reloads resume normal progress. No reset or confirmation is required.

Basket refinement: show priced stores first, collapse unmatched stores with reasons, highlight package minima per ingredient, and show five pair comparisons with the rest expandable. Ordinary Shopoclick Kazan prices retain the oldest stated publication date, expire after 72 hours, and never become promotion weights. Android 1.1 refreshes only the fixed public price-feed URL over HTTPS; cached data has the same expiry checks. Personal menu data remains local.
