/* Local edition: no tracking, remote requests, subscription or payment. */
window.__LF_PREVIEW__ = 1;
window.ym = function () {};
(() => {
  const startUrl = new URL(location.href);
  if (startUrl.searchParams.get('restart') === '1') {
    try {
      for (const key of Object.keys(localStorage)) {
        if (!key.startsWith('lf_var_') || !key.endsWith('_progress')) continue;
        try {
          const progress = JSON.parse(localStorage.getItem(key));
          if (progress?.v === 1 && progress.state) {
            progress.screen = 2;
            localStorage.setItem(key, JSON.stringify(progress));
          }
        } catch { /* Ignore unrelated or damaged saved progress. */ }
      }
    } catch { /* Without saved progress the quiz already starts with stores. */ }
    startUrl.searchParams.delete('restart');
    history.replaceState(null, '', startUrl.pathname + startUrl.search + startUrl.hash);
  }
  const nativeFetch = window.fetch.bind(window);
  window.fetch = (input, init) => {
    const url = new URL(typeof input === 'string' ? input : input.url, location.href);
    if (url.origin !== location.origin) return Promise.reject(new Error('External requests are disabled'));
    return nativeFetch(input, init);
  };
  navigator.sendBeacon = () => true;
  function openMenu(event) {
    const button = event.target.closest('button');
    if (!button) return;
    const title = document.querySelector('h1')?.textContent;
    if (button.textContent.trim() === 'Готово' && title === 'В какие дни готовишь?') {
      event.preventDefault(); event.stopImmediatePropagation();
      location.assign('/menu.html');
    }
  }
  document.addEventListener('click', openMenu, true);
  document.addEventListener('keydown', event => {
    if(event.key === 'Enter' && document.querySelector('h1')?.textContent === 'В какие дни готовишь?' && event.target.tagName !== 'BUTTON') {
      event.preventDefault();event.stopImmediatePropagation();location.assign('/menu.html');
    }
  }, true);
})();
