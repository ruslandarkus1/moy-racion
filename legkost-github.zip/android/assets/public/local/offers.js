// Verified catalog observations, independent from the recipe estimate engine.
export function currentOffers(feed,now=new Date()){
  if(feed?.schema!==1||feed.city!=='Казань'||!Array.isArray(feed.offers))return [];
  const checked=Date.parse(feed.checkedAt),age=now.getTime()-checked;
  if(!Number.isFinite(checked)||age>36*3600000||age< -300000)return [];
  const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Moscow',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  return feed.offers.filter(o=>o.city==='Казань'&&typeof o.price==='number'&&Number.isFinite(o.price)&&o.price>0&&(o.sourceType==='observed-price'?/^\d{4}-\d{2}-\d{2}$/.test(o.sourceUpdated)&&o.sourceUpdated<=today&&now.getTime()-Date.parse(o.sourceUpdated+'T00:00:00+03:00')<72*3600000:o.starts<=today&&o.ends>=today)&&safeSource(o.source));
}
export function safeSource(value){try{const u=new URL(value);return u.protocol==='https:'&&(u.hostname==='kazan.shopoclick.ru'||u.hostname==='proshoper.ru'||u.hostname.endsWith('.proshoper.ru'));}catch{return false;}}
export function forIngredients(feed,ids,now){const wanted=new Set(ids);return currentOffers(feed,now).filter(o=>wanted.has(o.ingredient)).sort((a,b)=>a.ingredient.localeCompare(b.ingredient)||((a.pricePerKg??Infinity)-(b.pricePerKg??Infinity))||a.price-b.price);}
export function packCost(offer,grams){if(!Number.isFinite(offer.packGrams)||offer.packGrams<=0||!Number.isFinite(offer.price)||offer.price<=0||!Number.isFinite(grams)||grams<=0)return null;const packs=Math.max(1,Math.ceil((grams-1e-7)/offer.packGrams));return {packs,cost:Math.round(packs*offer.price*100)/100};}
