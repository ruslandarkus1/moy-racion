export const DEFAULTS = {stores:['mag'],adults:2,kids:[],meals:['breakfast','lunch','dinner'],famMeals:['fam-dinner'],budget:5600,sex:'f',diet:'omni',likedDishes:[],seenDishes:0,allergies:[],dislikes:[],stopFoods:[],kitchen:['stove','oven','micro'],age:29,height:164,weight:63,goal:'lose',target:58,pace:'sure',life:2,cycle:null,periodDate:null,cycleLen:28,normMode:'balance',normAdjust:0,normManual:{p:null,f:null,cAdjust:0},coffee:null,drinks:['latte'],cups:2,spoons:1,repeat:2,days:['wed','sat']};
export const MEALS = {breakfast:'Завтрак',lunch:'Обед',dinner:'Ужин',snack:'Перекус'};
export const DAY_IDS = ['mon','tue','wed','thu','fri','sat','sun'];
export const DAYS = ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];
export const SHORT_DAYS = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
export const STORE_NAMES = {mag:'Магнит',p5:'Пятёрочка',dixy:'Дикси',chizh:'Чижик',svet:'Светофор',perek:'Перекрёсток',lenta:'Лента',auchan:'Ашан',metro:'Метро',vv:'ВкусВилл',azbuka:'Азбука вкуса',lavka:'Яндекс Лавка',sam:'Самокат'};
export const STORE_FACTORS = {mag:1,p5:.97,dixy:1,chizh:.85,svet:.85,perek:1.1,lenta:1,auchan:1,metro:.95,vv:1.4,azbuka:1.7,lavka:1.25,sam:1.2};
const list = (value, fallback, valid) => Array.isArray(value) ? [...new Set(value.filter(x=>typeof x==='string' && (!valid || valid.includes(x))).slice(0,60))] : [...fallback];
const number = (value,min,max,fallback) => typeof value==='number' && Number.isFinite(value) ? Math.max(min,Math.min(max,value)) : fallback;
export function normalizeProfile(input={}) {
  const result=structuredClone(DEFAULTS);
  if(!input || typeof input!=='object' || Array.isArray(input)) return result;
  const allowed={stores:Object.keys(STORE_NAMES),meals:Object.keys(MEALS),famMeals:Object.keys(MEALS).map(x=>'fam-'+x),kitchen:['stove','oven','micro','multi','air','blend','steam','grill'],days:DAY_IDS,drinks:['latte','capp','amer','mtch','cacao','flat'],allergies:['nuts','glut','lact','pnut','sea','eggs','hony','soy','fish','citr','ses'],dislikes:['mush','onio','garl','oliv','eggp','cila','spic','sugr','pork','beef','caff','tofu']};
  for(const [key,options] of Object.entries(allowed))result[key]=list(input[key],result[key],options);
  for(const [key,options] of Object.entries({sex:['f','m'],diet:['omni','pesc','veget','vegan'],goal:['lose','keep','gain'],pace:['soft','sure','fast'],normMode:['balance','protein','lowcarb']}))if(options.includes(input[key]))result[key]=input[key];
  for(const [key,min,max] of [['adults',1,8],['age',14,100],['height',100,250],['weight',30,300],['target',30,300],['life',0,4],['budget',0,1000000],['normAdjust',-5000,5000],['cups',0,20],['spoons',0,20],['repeat',1,3],['cycleLen',15,60],['seenDishes',0,24]])result[key]=number(input[key],min,max,result[key]);
  for(const key of ['adults','age','life','cups','spoons','repeat'])result[key]=Math.round(result[key]);
  result.kids=Array.isArray(input.kids)?input.kids.filter(x=>typeof x==='number'&&Number.isFinite(x)&&x>=0&&x<=17).slice(0,10).map(Math.round):[];
  result.likedDishes=Array.isArray(input.likedDishes)?[...new Set(input.likedDishes.filter(x=>Number.isInteger(x)&&x>=0&&x<24))]:[];
  result.stopFoods=list(input.stopFoods,[]).map(s=>s.trim().slice(0,60)).filter(Boolean);
  result.coffee=['yes','no'].includes(input.coffee)?input.coffee:null;
  result.cycle=['sync','preg','no'].includes(input.cycle)?input.cycle:null;
  result.periodDate=typeof input.periodDate==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(input.periodDate)?input.periodDate:null;
  const manual=input.normManual;
  if(manual&&typeof manual==='object')result.normManual={p:manual.p===null?null:number(manual.p,0,1000,null),f:manual.f===null?null:number(manual.f,0,1000,null),cAdjust:number(manual.cAdjust,-1000,1000,0)};
  if(typeof input.manualKcal==='number')result.manualKcal=number(input.manualKcal,500,6000,1800);
  return result;
}
export function getNutrition(profile) {
  const p=normalizeProfile(profile),activity=[1.2,1.375,1.46,1.55,1.72][p.life];
  // Same published Harris–Benedict calculation as the questionnaire.
  const bmr=p.sex==='m'?66+13.7*p.weight+5*p.height-6.8*p.age:655+9.6*p.weight+1.8*p.height-4.7*p.age;
  const kcal=p.manualKcal??Math.max(500,10*Math.round((bmr*activity-350)/10)+p.normAdjust);
  const [protein,fat]={balance:[26,30],protein:[34,30],lowcarb:[30,38]}[p.normMode];
  const gramsP=p.normManual.p??Math.round(kcal*protein/400),gramsF=p.normManual.f??Math.round(kcal*fat/900);
  const gramsC=Math.max(0,Math.round((kcal-gramsP*4-gramsF*9)/4)+p.normManual.cAdjust);
  const energy=(p.normManual.p!==null||p.normManual.f!==null||p.normManual.cAdjust)?gramsP*4+gramsF*9+gramsC*4:kcal;
  return {kcal:Math.round(energy),p:gramsP,f:gramsF,c:gramsC,restricted:p.age<18||p.cycle==='preg'};
}
export function drinkNutrition(profile) {
  if(profile.coffee!=='yes')return {kcal:0,p:0,f:0,c:0};
  const values={latte:{kcal:130,p:6,f:6,c:12},capp:{kcal:85,p:4,f:4,c:8},amer:{kcal:3,p:0,f:0,c:0},mtch:{kcal:110,p:4,f:4,c:14},cacao:{kcal:140,p:6,f:6,c:16},flat:{kcal:100,p:5,f:5,c:9}};
  const picks=profile.drinks.filter(x=>values[x]);
  const total={kcal:profile.spoons*20,c:profile.spoons*5,p:0,f:0};
  for(const x of picks)for(const key of ['kcal','p','f','c'])total[key]+=values[x][key]/picks.length;
  for(const key of ['kcal','p','f','c'])total[key]*=profile.cups;
  return total;
}
export function recipeNutrition(recipe,data,scale=1) {
  return Object.fromEntries(['kcal','p','f','c'].map(key=>[key,recipe.ingredients.reduce((sum,item)=>sum+data.ingredients[item.id][key]*item.grams*scale/100,0)]));
}
export function recipeCost(recipe,data,profile,scale=1,prices={}) {
  const multiplier=STORE_FACTORS[profile.stores[0]]??1;
  return recipe.ingredients.reduce((sum,item)=>sum+(prices[item.id]??data.ingredients[item.id].price*multiplier)*item.grams*scale/1000,0);
}
const normalizeText=s=>s.toLocaleLowerCase('ru-RU').replaceAll('ё','е');
export function compatible(recipe,profile,data) {
  if(recipe.methods.length&&!recipe.methods.some(x=>profile.kitchen.includes(x)))return false;
  const banned=new Set([...profile.allergies,...profile.dislikes]);
  for(const item of recipe.ingredients){
    const food=data.ingredients[item.id];
    if(!food)return false;
    if(food.tags.some(tag=>banned.has(tag)))return false;
    if(profile.diet==='vegan'&&food.kind!=='plant')return false;
    if(profile.diet==='veget'&&['meat','fish'].includes(food.kind))return false;
    if(profile.diet==='pesc'&&food.kind==='meat')return false;
    const haystack=normalizeText(food.name);
    if(profile.stopFoods.some(stop=>normalizeText(stop).split(/\s+/).filter(w=>w.length>=3).some(word=>haystack.includes(word.length>5?word.slice(0,-2):word))))return false;
  }
  return true;
}
export function selectedMeals(p) {return Object.keys(MEALS).filter(key=>p.meals.includes(key)||p.famMeals.includes('fam-'+key));}
export function portions(p,meal,personalScale=1) {
  const family=p.famMeals.includes('fam-'+meal);
  return family?personalScale*p.adults+p.kids.length*.6:personalScale;
}
export function hash(text){let n=2166136261;for(const char of String(text)){n^=char.charCodeAt(0);n=Math.imul(n,16777619)}return n>>>0;}
export function weekKey(date=new Date()) {const d=new Date(date);d.setHours(12,0,0,0);d.setDate(d.getDate()-((d.getDay()+6)%7));return dateKey(d);}
export function dateKey(date){return [date.getFullYear(),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-');}
export function isDateKey(value){if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;const d=new Date(value+'T12:00:00');return Number.isFinite(d.getTime())&&dateKey(d)===value;}
export function shiftDate(key,days){const d=new Date(key+'T12:00:00');d.setDate(d.getDate()+days);return dateKey(d);}
export function cookingDay(profile,day){const picks=profile.days.map(x=>DAY_IDS.indexOf(x)).filter(x=>x>=0);if(!picks.length)return day;return Math.max(...picks.map(x=>x<=day?x:x-7));}
export function buildPlan(profile,data,week=weekKey(),nonce=0,prices={}) {
  const p=normalizeProfile(profile),norm=getNutrition(p),drinks=drinkNutrition(p),meals=selectedMeals(p);
  if(!meals.length)throw new Error('Выбери хотя бы один приём пищи в настройках.');
  if(norm.restricted)throw new Error('Для возраста до 18 лет, беременности и ГВ автоматический расчёт порций не используется. Рецепты доступны отдельно; для меню укажи согласованную со специалистом норму и используй взрослый профиль без этого режима.');
  if(norm.kcal<1200)throw new Error('Норма ниже 1200 ккал. Уточни её в настройках перед составлением рациона.');
  if(p.coffee==='yes'&&p.cups>0){
    if(!p.drinks.length)throw new Error('Выбери вид напитка или отключи учёт напитков.');
    if(p.drinks.some(x=>x!=='amer')&&(p.diet==='vegan'||p.allergies.includes('lact')))throw new Error('Напитки с молоком не подходят к выбранным ограничениям. Выбери американо или отключи напитки.');
    if(p.spoons>0&&p.dislikes.includes('sugr'))throw new Error('Сахар в напитках конфликтует с исключением сахара. Укажи 0 ложек.');
    if(p.dislikes.includes('caff'))throw new Error('Выбранные напитки содержат кофеин. Отключи их или измени ограничение.');
  }
  if(drinks.kcal>=norm.kcal*.6)throw new Error('Напитки занимают больше половины дневной нормы. Уточни их количество или норму калорий.');
  const eligible=data.recipes.filter(r=>compatible(r,p,data));
  const pools=Object.fromEntries(meals.map(meal=>[meal,eligible.filter(r=>r.meals.includes(meal))]));
  for(const meal of meals)if(!pools[meal].length)throw new Error(`Для приёма «${MEALS[meal]}» нет рецептов с выбранными ограничениями и техникой. Измени настройки или выбери другой приём пищи. Ограничения не будут сняты автоматически.`);
  const ratio=meals.includes('snack')?{breakfast:.25,lunch:.33,dinner:.32,snack:.1}:{breakfast:.28,lunch:.37,dinner:.35,snack:.1};
  let best=null;
  for(let attempt=0;attempt<12;attempt++){
    const counts=new Map(),days=[];
    for(let day=0;day<7;day++){
      const slots=[];
      for(const meal of meals){
        const target=(norm.kcal-drinks.kcal)*ratio[meal];
        const candidates=pools[meal].filter(r=>(counts.get(r.id)??0)<p.repeat);
        if(!candidates.length)throw new Error(`Недостаточно разных рецептов для «${MEALS[meal]}» при лимите ${p.repeat} повтора. Увеличь число повторов или измени ограничения.`);
        const ranked=candidates.map(recipe=>{
          const nutrition=recipeNutrition(recipe,data),scale=target/nutrition.kcal,totalScale=portions(p,meal,scale);
          const cost=recipeCost(recipe,data,p,totalScale,prices),allowed=p.budget/7/meals.length;
          const proteinError=Math.abs(nutrition.p*4/nutrition.kcal-norm.p*4/norm.kcal);
          const noise=(hash(`${week}:${nonce}:${attempt}:${day}:${meal}:${recipe.id}`)%1000)/1000;
          const score=cost/Math.max(10,allowed)*(attempt===0?.4:attempt/4)+proteinError*4+(scale>2?scale*.5:0)+(counts.get(recipe.id)??0)*.35+noise*.75-(p.likedDishes.includes(recipe.like)?.45:0);
          return {recipe,score,scale,totalScale,cost};
        }).sort((a,b)=>a.score-b.score);
        const chosen=ranked[0];counts.set(chosen.recipe.id,(counts.get(chosen.recipe.id)??0)+1);
        const fresh=chosen.recipe.methods.length===0||chosen.recipe.methods.every(x=>x==='blend');
        const cookOn=fresh?day:cookingDay(p,day),age=day-cookOn;
        slots.push({meal,recipeId:chosen.recipe.id,scale:chosen.scale,totalScale:chosen.totalScale,cookOn,storage:fresh?'fresh':age>=2?'freeze':'fridge'});
      }
      days.push({day,date:shiftDate(week,day),slots});
    }
    const plan={version:1,week,nonce,profile:p,days,checked:[],createdAt:new Date().toISOString()};
    plan.total=shoppingList(plan,data,prices).reduce((sum,x)=>sum+x.cost,0);
    if(!best||plan.total<best.total)best=plan;
    if(plan.total<=p.budget){best=plan;break;}
  }
  return best;
}
export function shoppingList(plan,data,prices={}) {
  const totals=new Map();
  for(const day of plan.days)for(const slot of day.slots){
    const r=data.recipes.find(x=>x.id===slot.recipeId);if(!r)throw new Error('Не найден рецепт из сохранённого плана. Составь меню заново.');
    for(const item of r.ingredients)totals.set(item.id,(totals.get(item.id)??0)+item.grams*slot.totalScale);
  }
  const p=plan.profile;
  if(p.coffee==='yes'&&p.drinks.length){
    const milkPerCup={latte:250,capp:160,amer:0,mtch:200,cacao:220,flat:190};
    const milkGrams=p.drinks.reduce((sum,x)=>sum+(milkPerCup[x]??0),0)/p.drinks.length*p.cups*7;
    if(milkGrams)totals.set('milk',(totals.get('milk')??0)+milkGrams);
    for(const drink of p.drinks){const id=drink==='mtch'?'matcha':drink==='cacao'?'cocoa':'coffee';const dose=drink==='mtch'?2:drink==='cacao'?8:10;if(data.ingredients[id])totals.set(id,(totals.get(id)??0)+dose*p.cups*7/p.drinks.length);}
  }
  if(p.coffee==='yes'&&p.spoons){totals.set('sugar',(totals.get('sugar')??0)+p.cups*p.spoons*5*7);}
  return [...totals].map(([id,grams])=>{const food=data.ingredients[id];const price=prices[id]??food.price*(STORE_FACTORS[p.stores[0]]??1);return {id,grams,price,cost:grams*price/1000,...food,price};}).sort((a,b)=>a.category.localeCompare(b.category,'ru')||a.name.localeCompare(b.name,'ru'));
}
export function dayNutrition(day,data,profile) {
  const out=drinkNutrition(profile);
  for(const slot of day.slots){const r=data.recipes.find(x=>x.id===slot.recipeId),n=recipeNutrition(r,data,slot.scale);for(const key of ['kcal','p','f','c'])out[key]+=n[key];}
  return out;
}
export function replaceSlot(plan,data,dayIndex,meal,recipeId,prices={}) {
  const recipe=data.recipes.find(r=>r.id===recipeId),slot=plan.days[dayIndex]?.slots.find(x=>x.meal===meal);
  if(!recipe||!slot||!recipe.meals.includes(meal)||!compatible(recipe,plan.profile,data))throw new Error('Этот рецепт не соответствует выбранным ограничениям.');
  const occurrences=plan.days.flatMap(d=>d.slots).filter(s=>s.recipeId===recipeId&&s!==slot).length;
  if(occurrences>=plan.profile.repeat)throw new Error('Достигнут выбранный лимит повторов этого блюда.');
  const oldRecipe=data.recipes.find(r=>r.id===slot.recipeId),oldKcal=recipeNutrition(oldRecipe,data,slot.scale).kcal;
  const scale=oldKcal/recipeNutrition(recipe,data).kcal;
  slot.recipeId=recipe.id;slot.scale=scale;slot.totalScale=portions(plan.profile,meal,scale);
  const fresh=recipe.methods.length===0||recipe.methods.every(x=>x==='blend');
  slot.cookOn=fresh?dayIndex:cookingDay(plan.profile,dayIndex);slot.storage=fresh?'fresh':dayIndex-slot.cookOn>=2?'freeze':'fridge';
  plan.total=shoppingList(plan,data,prices).reduce((sum,x)=>sum+x.cost,0);plan.checked=[];
  return plan;
}
export function validatePlan(plan,data){
  try{
    if(!plan||plan.version!==1||!isDateKey(plan.week)||!plan.profile||!Array.isArray(plan.days)||plan.days.length!==7||!Array.isArray(plan.checked))return false;
    const p=normalizeProfile(plan.profile),counts=new Map();
    for(const [index,day] of plan.days.entries()){
      if(day.day!==index||day.date!==shiftDate(plan.week,index)||!Array.isArray(day.slots)||!day.slots.length||day.slots.length>4)return false;
      if(new Set(day.slots.map(s=>s.meal)).size!==day.slots.length)return false;
      for(const s of day.slots){
        const r=data.recipes.find(r=>r.id===s.recipeId);
        if(!r||!r.meals.includes(s.meal)||!selectedMeals(p).includes(s.meal)||!compatible(r,p,data)||typeof s.scale!=='number'||!Number.isFinite(s.scale)||s.scale<=0||s.scale>30||typeof s.totalScale!=='number'||!Number.isFinite(s.totalScale)||Math.abs(s.totalScale-portions(p,s.meal,s.scale))>.001)return false;
        const fresh=r.methods.length===0||r.methods.every(x=>x==='blend'),cookOn=fresh?index:cookingDay(p,index);
        if(s.cookOn!==cookOn||s.storage!==(fresh?'fresh':index-cookOn>=2?'freeze':'fridge'))return false;
        counts.set(r.id,(counts.get(r.id)??0)+1);if(counts.get(r.id)>p.repeat)return false;
      }
    }
    return true;
  }catch{return false;}
}
