package ru.legkost.offline;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String ORIGIN = "https://" + HOST;
    private static final String CSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'";
    private static final int OPEN_FILE = 100, SAVE_FILE = 101;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingExport;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(252, 248, 242));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Only user-selected SAF documents; no storage permission.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        web.setBackgroundColor(Color.rgb(252, 248, 242));
        web.addJavascriptInterface(new LocalDocuments(), "LegkostAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!trusted(uri)) return reply(403, "text/plain", "External requests disabled");
                String path = uri.getPath();
                if (path == null || path.indexOf('\\') >= 0 || path.contains("..") || path.indexOf('\0') >= 0) return reply(403, "text/plain", "Invalid path");
                if (path.equals("/local/kazan-offers.json")) return prices();
                if (path.equals("/api/ab-config")) return asset("config/ab-config.json");
                if (path.equals("/api/session")) return reply(200, "application/json", "{\"ok\":true,\"access\":{\"paid\":false,\"verified\":false,\"pending\":false},\"payment_status\":\"local_no_subscription\"}");
                if (path.startsWith("/api/finik/")) return reply(410, "application/json", "{\"error\":\"Payments disabled\"}");
                if (path.startsWith("/api/")) return reply(200, "application/json", "{\"ok\":true}");
                if (path.equals("/") || path.equals("/racion") || path.equals("/racion/")) path = "/index.html";
                return asset("public" + path);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (trusted(request.getUrl())) return false;
                Uri destination=request.getUrl();
                String host=destination.getHost();
                if (request.isForMainFrame() && "https".equals(destination.getScheme()) && ("proshoper.ru".equals(host) || "kazan.shopoclick.ru".equals(host))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,destination)); } catch (Exception e) { message("Не удалось открыть источник цены"); }
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), OPEN_FILE); }
                catch (Exception e) { fileCallback.onReceiveValue(null); fileCallback = null; message("Не удалось открыть выбор файла"); }
                return true;
            }
        });
        web.loadUrl(ORIGIN + "/racion");
    }

    private WebResourceResponse prices() {
        HttpsURLConnection connection=null;
        try {
            connection=(HttpsURLConnection)new URL("https://ruslandarkus1.github.io/moy-racion/local/kazan-offers.json").openConnection();
            connection.setConnectTimeout(5000);connection.setReadTimeout(5000);connection.setInstanceFollowRedirects(false);
            if(connection.getResponseCode()!=200)throw new IllegalStateException();
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream input=connection.getInputStream()) { byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>2_000_000)throw new IllegalStateException();} }
            String body=new String(bytes.toByteArray(),StandardCharsets.UTF_8);
            JSONObject json=new JSONObject(body);
            if(json.getInt("schema")!=1 || !"Казань".equals(json.getString("city")) || json.getJSONArray("stores").length()!=13 || json.getJSONArray("offers").length()>10000)throw new IllegalStateException();
            getSharedPreferences("prices",MODE_PRIVATE).edit().putString("feed",body).apply();
            return reply(200,"application/json",body);
        } catch(Exception e) {
            String cached=getSharedPreferences("prices",MODE_PRIVATE).getString("feed",null);
            return cached==null?asset("public/local/kazan-offers.json"):reply(200,"application/json",cached);
        } finally { if(connection!=null)connection.disconnect(); }
    }

    private static boolean trusted(Uri uri) { return "https".equals(uri.getScheme()) && HOST.equals(uri.getHost()); }
    private void message(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
    private WebResourceResponse response(int status, String mime, InputStream stream) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Security-Policy", CSP);
        headers.put("X-Content-Type-Options", "nosniff");
        headers.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, "UTF-8", status, status == 200 ? "OK" : "Unavailable", headers, stream);
    }
    private WebResourceResponse reply(int status, String mime, String text) {
        return response(status, mime, new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
    }
    private WebResourceResponse asset(String name) {
        try {
            String lower = name.toLowerCase(Locale.ROOT);
            String mime = lower.endsWith(".js") ? "text/javascript" : lower.endsWith(".css") ? "text/css" : lower.endsWith(".json") ? "application/json" : lower.endsWith(".webp") ? "image/webp" : lower.endsWith(".png") ? "image/png" : lower.endsWith(".woff2") ? "font/woff2" : lower.endsWith(".ico") ? "image/x-icon" : "text/html";
            return response(200, mime, getAssets().open(name));
        } catch (Exception e) { return reply(404, "text/plain", "Not found"); }
    }

    private final class LocalDocuments {
        @JavascriptInterface public void save(String name, String type, String text) {
            if (name == null || text == null || text.length() > 5_000_000) return;
            runOnUiThread(() -> {
                if (web.getUrl() == null || !trusted(Uri.parse(web.getUrl()))) return;
                if (pendingExport != null) { message("Сначала заверши сохранение предыдущего файла"); return; }
                pendingExport = text.getBytes(StandardCharsets.UTF_8);
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(type != null && type.startsWith("application/json") ? "application/json" : "text/plain");
                intent.putExtra(Intent.EXTRA_TITLE, name.replace('/', '_').replace('\\', '_'));
                try { startActivityForResult(intent, SAVE_FILE); }
                catch (Exception e) { pendingExport = null; message("Не удалось открыть сохранение файла"); }
            });
        }
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                if (web.getUrl() != null && trusted(Uri.parse(web.getUrl()))) ((PrintManager) getSystemService(PRINT_SERVICE)).print("Мой рацион", web.createPrintDocumentAdapter("Рацион"), null);
            });
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OPEN_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        }
        if (request == SAVE_FILE) {
            byte[] contents = pendingExport;
            pendingExport = null;
            if (result == RESULT_OK && data != null && data.getData() != null && contents != null) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (stream == null) throw new IllegalStateException();
                    stream.write(contents);
                    message("Файл сохранён");
                } catch (Exception e) { message("Не удалось сохранить файл. Попробуй ещё раз"); }
            }
        }
    }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        web.removeJavascriptInterface("LegkostAndroid");
        web.destroy();
        super.onDestroy();
    }
}
