"""Build an offline-capable GitHub Pages edition; no server or user data required."""
from pathlib import Path
import argparse, hashlib, json, re, shutil

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--base',default='/legkost/')
args=parser.parse_args()
base='/'+args.base.strip('/')+'/'
if base=='//':base='/'
if not re.fullmatch(r'/[A-Za-z0-9_./-]*',base) or '..' in base:raise ValueError('Invalid base path')
source=root/'source'
out=root/'web'
out.mkdir(exist_ok=True)
paths=re.compile(r'/(?:_next/|racion2/|v3/|local/|api/|menu\.html|racion(?=[?\s\'"\\/]|$)|favicon\.ico)')
for path in (source/'public').rglob('*'):
    if not path.is_file():continue
    dest=out/path.relative_to(source/'public')
    dest.parent.mkdir(parents=True,exist_ok=True)
    if path.suffix in ('.html','.js','.css','.json'):
        text=paths.sub(lambda m:base+m.group()[1:],path.read_text(encoding='utf-8'))
        if path.suffix=='.html':
            # React Flight text records declare UTF-8 byte lengths, changed by the base path.
            flight=re.compile(r'self\.__next_f\.push\(\[1,("(?:\\.|[^"\\])*")\]\)')
            chunks=list(flight.finditer(text))
            edits=[]
            for index,match in enumerate(chunks[:-1]):
                payload=json.loads(match.group(1))
                if re.search(r':T[0-9a-f]+,$',payload):
                    following=json.loads(chunks[index+1].group(1))
                    payload=re.sub(r':T[0-9a-f]+,$',lambda m:':T'+format(len(following.encode('utf-8')),'x')+',',payload)
                    edits.append((match.start(1),match.end(1),json.dumps(payload,ensure_ascii=False)))
            for start,end,replacement in reversed(edits):text=text[:start]+replacement+text[end:]
            text=text.replace('<head>','<head><link rel="manifest" href="'+base+'manifest.webmanifest"><meta name="theme-color" content="#fcf8f2"><script src="'+base+'site-boot.js"></script>',1)
        dest.write_text(text,encoding='utf-8')
    else:shutil.copyfile(path,dest)
(out/'racion').mkdir(exist_ok=True)
shutil.copyfile(out/'index.html',out/'racion/index.html')
shutil.copytree(source/'config',out/'config',dirs_exist_ok=True)
(out/'.nojekyll').touch()
boot="""(()=>{const base=BASE;const original=window.fetch.bind(window);window.fetch=(input,init)=>{const url=new URL(typeof input==='string'?input:input.url,location.href);if(url.origin!==location.origin)return Promise.reject(new Error('External requests disabled'));const path=url.pathname;if(path===base+'api/ab-config')return original(base+'config/ab-config.json');if(path.startsWith(base+'api/')){const payment=path.startsWith(base+'api/finik/');return Promise.resolve(new Response(JSON.stringify(payment?{error:'Payments disabled'}:{ok:true,access:{paid:false,verified:false,pending:false},payment_status:'local_no_subscription'}),{status:payment?410:200,headers:{'Content-Type':'application/json'}}));}return original(input,init);};if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register(base+'sw.js',{scope:base}).catch(()=>{}));})();""".replace('BASE',json.dumps(base))
(out/'site-boot.js').write_text(boot,encoding='utf-8')
manifest={'name':'Мой рацион','short_name':'Рацион','lang':'ru','start_url':base+'racion/','scope':base,'display':'standalone','background_color':'#fcf8f2','theme_color':'#fcf8f2','icons':[{'src':base+'icons/icon-192.png','sizes':'192x192','type':'image/png'},{'src':base+'icons/icon-512.png','sizes':'512x512','type':'image/png'}]}
(out/'manifest.webmanifest').write_text(json.dumps(manifest,ensure_ascii=False),encoding='utf-8')
shutil.copytree(root/'icons',out/'icons',dirs_exist_ok=True)
files=sorted(base+p.relative_to(out).as_posix() for p in out.rglob('*') if p.is_file() and p.name!='sw.js')
version=hashlib.sha256(''.join(hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='sw.js').encode()).hexdigest()[:12]
sw="""const CACHE='ration-VERSION',BASE=ROOT,FILES=LIST;self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()));});self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('ration-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==location.origin||!u.pathname.startsWith(BASE))return;e.respondWith(caches.open(CACHE).then(async c=>{let path=u.pathname;if(path===BASE||path===BASE+'racion/'||path===BASE+'racion')path=BASE+'racion/index.html';const cached=await c.match(path);return cached||fetch(e.request);}));});""".replace('VERSION',version).replace('ROOT',json.dumps(base)).replace('LIST',json.dumps(files))
(out/'sw.js').write_text(sw,encoding='utf-8')
print(json.dumps({'base':base,'files':len(files),'version':version}))
