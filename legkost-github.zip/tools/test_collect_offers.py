import unittest
from collect_offers import dates, parse_catalog, ingredient, parse_observed

class CollectorTests(unittest.TestCase):
    def test_dates_and_new_year(self):
        self.assertEqual(dates('с 18 по 24 ноября 2026'),('2026-11-18','2026-11-24'))
        self.assertEqual(dates('с 28 декабря по 5 января 2027'),('2026-12-28','2027-01-05'))
        self.assertIsNone(dates('неизвестный срок'))
    def test_source_price_pack_and_expiry(self):
        body='<h2 class="catalog_dates">с 18 по 24 ноября 2026</h2><article id="id_product_123" class="product"><div class="product__name">Хлопья овсяные 400г</div><span class="product__price-new">79<span class="small">99</span></span><span class="product__price-old line-through2">99<span class="small">99</span></span></article>'
        found=parse_catalog(body,'https://proshoper.ru/kazan/actions/test/','mag','2026-11-24')
        self.assertEqual(len(found),1)
        self.assertEqual(found[0]['price'],79.99)
        self.assertEqual(found[0]['pricePerKg'],199.97)
        self.assertEqual(parse_catalog(body,'https://proshoper.ru/kazan/actions/test/','mag','2026-11-25'),[])
        self.assertEqual(parse_catalog(body.replace('catalog_dates','unknown'),'https://proshoper.ru/kazan/actions/test/','mag','2026-11-24'),[])
    def test_unrelated_processed_products_are_not_replacements(self):
        self.assertIsNone(ingredient('Напиток молочный шоколадный 1л'))
        self.assertIsNone(ingredient('Молоко детское 200мл'))
        self.assertIsNone(ingredient('Молоко сгущенное цельное 8.5% 270г'))
        self.assertEqual(ingredient('Морковь мытая 1кг'),'carrot')

class ObservationTests(unittest.TestCase):
    def test_publication_age_and_no_invented_discount(self):
        body='Казань. Цены обновлены 24.11.2026. Цены обновлены 22.11.2026.<tbody id="mg2-list"><tr data-p="54.00"><td><a class="mg2-pill" href="/items/produkty/makarony/test">Макфа 450 г</a></td><td>другие от 99 ₽</td></tr></tbody>'
        found=parse_observed(body,'https://kazan.shopoclick.ru/magazin/chizhik/makarony','chizh','2026-11-24','Макароны')
        self.assertEqual(len(found),1);self.assertEqual(found[0]['price'],54);self.assertEqual(found[0]['packGrams'],450)
        self.assertIsNone(found[0]['oldPrice']);self.assertEqual(found[0]['sourceUpdated'],'2026-11-22')
        self.assertNotIn('ends',found[0]);self.assertEqual(parse_observed(body,'https://kazan.shopoclick.ru/','chizh','2026-11-25','Макароны'),[])
        self.assertEqual(parse_observed(body.replace('Казань','Москва'),'https://kazan.shopoclick.ru/','chizh','2026-11-24','Макароны'),[])

if __name__=='__main__':unittest.main()
