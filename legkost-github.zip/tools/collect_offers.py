"""Collect public Kazan catalog facts. Missing/expired data never becomes a price."""
from pathlib import Path
from datetime import datetime, date, timezone, timedelta
from urllib.request import Request, urlopen
from urllib.parse import urljoin, urlparse
from concurrent.futures import ThreadPoolExecutor
import re, json, html, hashlib, argparse

STORES={'mag':('Магнит','magnit-magazin','https://magnit.ru/catalog'),'p5':('Пятёрочка','pyaterochka','https://5ka.ru/'),'dixy':('Дикси','diksi','https://dixy.ru/'),'chizh':('Чижик','chizhik','https://chizhik.club/'),'svet':('Светофор','svetofor','https://svetofor-nsk.ru/'),'perek':('Перекрёсток','perekrestok','https://www.perekrestok.ru/'),'lenta':('Лента','lenta','https://lenta.com/'),'auchan':('Ашан','ashan','https://www.auchan.ru/'),'metro':('Метро','metro','https://metro-cc.ru/sales'),'vv':('ВкусВилл','vkusvill','https://vkusvill.ru/'),'azbuka':('Азбука вкуса','azbuka-vkusa','https://av.ru/'),'lavka':('Яндекс Лавка','yandeks-lavka','https://lavka.yandex.ru/'),'sam':('Самокат','samokat','https://samokat.ru/')}
RULES={'rice':r'^рис\b','buckwheat':r'^крупа гречнев|^гречка\b','oats':r'^хлопья овсяные|^овсяные хлопья','millet':r'^пшено\b','pasta':r'^макаронные изделия|^макароны\b','flour':r'^мука пшеничная','lentils':r'^чечевица\b','chicken':r'^филе (?:цыпленка|куриное)|^грудка (?:цыпленка|куриная)','turkey':r'^филе индейки','beef':r'^говядина\b','pork':r'^свинина\b','cod':r'^треска\b|^филе трески','salmon':r'^филе лосося|^лосось\b','shrimp':r'^креветки\b','milk':r'^молоко\b','cream':r'^сливки\b','curd':r'^творог\b','yogurt':r'^йогурт\b','cheese':r'^сыр (?!плавлен|творож|мягк|камамбер|моцарел|сулугуни|брынза)','sour':r'^сметана\b','egg':r'^яйц[оа]\b','tofu':r'^тофу\b','potato':r'^картофель\b','carrot':r'^морковь\b','onion':r'^лук репчатый','garlic':r'^чеснок\b','broccoli':r'^брокколи\b|^капуста брокколи','spinach':r'^шпинат\b','tomato':r'^томаты\b|^помидоры\b','cucumber':r'^огурцы\b','zucchini':r'^кабачки\b','cabbage':r'^капуста белокочанная','beet':r'^свекла\b','mushroom':r'^шампиньоны\b','eggplant':r'^баклажаны\b','pumpkin':r'^тыква\b','pepper':r'^перец сладкий|^перец (?:красный|желтый|зеленый)','apple':r'^яблоки\b','banana':r'^бананы\b','berries':r'^ягоды\b','raisins':r'^изюм\b','lemon':r'^лимоны?\b','walnut':r'^орех грецкий|^грецкий орех','peanut':r'^арахис\b','honey':r'^мед\b','sugar':r'^сахар(?:-песок)?\b','oil':r'^масло подсолнечное','oliveoil':r'^масло оливковое','bread':r'^хлеб\b','tuna':r'^тунец\b','mackerel':r'^скумбрия\b','pollock':r'^минтай\b|^филе минтая','squid':r'^кальмар\b','chickenliver':r'^печень (?:куриная|цыпленка)','cauliflower':r'^капуста цветная','celery':r'^сельдерей\b','radish':r'^редис\b','lettuce':r'^салат листовой','avocado':r'^авокадо\b','pear':r'^груши\b','orange':r'^апельсины\b','kiwi':r'^киви\b','prunes':r'^чернослив\b','apricots':r'^курага\b','almond':r'^миндаль\b','cashew':r'^кешью\b','mozzarella':r'^сыр моцарелла|^моцарелла','feta':r'^брынза\b','kefir':r'^кефир\b','butter':r'^масло сливочное','dill':r'^укроп\b','parsley':r'^петрушка\b','ginger':r'^имбирь\b'}
MONTHS={m:i+1 for i,m in enumerate('января февраля марта апреля мая июня июля августа сентября октября ноября декабря'.split())}
def clean(s):return html.unescape(re.sub('<[^>]+>',' ',s)).strip()
def fetch(url):
    with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; RationCatalog/1.0)'}),timeout=25) as r:
        if urlparse(r.url).hostname not in {'proshoper.ru','kazan.shopoclick.ru'}:raise ValueError('Unexpected source redirect')
        return r.read(8_000_000).decode('utf-8')
def dates(text):
    m=re.search(r'с\s+(\d{1,2})(?:\s+([а-я]+))?\s+по\s+(\d{1,2})\s+([а-я]+)\s+(20\d{2})',clean(text).lower())
    if not m:return None
    a,am,b,bm,y=m.groups()
    if bm not in MONTHS or (am and am not in MONTHS):return None
    try:
        end=date(int(y),MONTHS[bm],int(b));start=date(int(y),MONTHS[am or bm],int(a))
        if start>end and am:start=start.replace(year=start.year-1)
        return start.isoformat(),end.isoformat()
    except ValueError:return None
def ingredient(name):
    text=name.lower().replace('ё','е')
    if re.search(r'детск|безлактоз|шоколад|коктейль|десерт|соус|салат из|маринован|солен|копчен|сухарик|каша готов|конфет|напиток|пюре|сгущен|сахаром|сухое молоко|молоко сухое',text):return None
    return next((k for k,v in RULES.items() if re.search(v,text)),None)
def parse_catalog(body,url,store,today):
    headings=[(m.start(),dates(m.group())) for m in re.finditer(r'<h2[^>]*class="[^"]*catalog_dates[^>]*>.*?</h2>',body,re.S)]
    offers=[]
    for article in re.finditer(r'<article\b[^>]*>.*?</article>',body,re.S):
        ranges=[d for pos,d in headings if pos<article.start()]
        period=ranges[-1] if ranges else None
        if not period or not period[0]<=today<=period[1]:continue
        block=article.group();name=re.search(r'<div class="product__name">(.*?)</div>',block,re.S)
        value=re.search(r'class="product__price-new">(\d+)\s*<span[^>]*>(\d{2})</span>',block)
        identity=re.search(r'id="(id_product_\d+)"',block)
        if not name or not value or not identity:continue
        title=clean(name[1]);food=ingredient(title)
        if food=='potato' and re.search(r'пастеризован|шарики|дольки|фри',title.lower()):continue
        if not food:continue
        price=int(value[1])+int(value[2])/100
        if not 0<price<100000:continue
        old=re.search(r'class="product__price-old[^\"]*">(\d+)\s*<span[^>]*>(\d{2})</span>',block)
        before=int(old[1])+int(old[2])/100 if old else None
        weight=re.search(r'(\d+(?:[.,]\d+)?)\s*(кг|г)\b',title.lower())
        grams=round(float(weight[1].replace(',','.'))*(1000 if weight[2]=='кг' else 1),2) if weight else None
        multi=re.search(r'(\d+)\s*[xх×]\s*\d+(?:[.,]\d+)?\s*(?:кг|г)\b',title.lower())
        if grams and multi:grams*=int(multi[1])
        offers.append({'id':store+'-'+identity[1],'store':store,'ingredient':food,'name':title,'price':round(price,2),'oldPrice':before if before and before>price else None,'packGrams':grams,'pricePerKg':round(price*1000/grams,2) if grams and grams>0 else None,'starts':period[0],'ends':period[1],'source':url+'#'+identity[1],'conditions':'Цена из каталога для Казани. Проверь карту лояльности, наличие и условия в выбранном магазине.','sourceType':'catalog','city':'Казань'})
    return offers

# Observed prices are not promotions. The oldest publication date on a page wins.
SHOP_CATEGORIES={'makarony':'Макароны','moloko':'Молоко','slivki':'Сливки','smetana':'Сметана','tvorog':'Творог','slivochnoe-maslo':'Масло сливочное','sahar':'Сахар','maslo-podsolnechnoe':'Масло подсолнечное','muka-smesi-dlya-vypechki':'','krupy':'','ovoshchi':'','ptica':''}
SHOP_STORES={'mag':'magnit','p5':'pyaterochka','chizh':'chizhik','perek':'perekrestok','lenta':'lenta','auchan':'ashan','metro':'metro','sam':'samokat'}
def parse_observed(body,url,store,today,prefix=''):
    if 'Казани' not in body and 'Казань' not in body:return []
    stamps=[]
    for d,m,y in re.findall(r'Цены обновлены\s+(\d{2})\.(\d{2})\.(20\d{2})',clean(body)):
        try:stamps.append(date(int(y),int(m),int(d)))
        except ValueError:pass
    if not stamps:return []
    updated=min(stamps);age=(date.fromisoformat(today)-updated).days
    if not 0<=age<=2:return []
    table=re.search(r'<tbody id="mg2-list">(.*?)</tbody>',body,re.S)
    if not table:return []
    found=[]
    for row in re.findall(r'<tr\b.*?</tr>',table[1],re.S):
        amount=re.search(r'data-p="([0-9.]+)"',row)
        product=re.search(r'<a class="mg2-pill" href="(/items/[^"?#]+)">(.*?)</a>',row,re.S)
        if not amount or not product:continue
        title=clean(product[2]);full=title if ingredient(title) else (prefix+' '+title).strip();food=ingredient(full)
        if not food:continue
        price=float(amount[1]);weight=re.search(r'(\d+(?:[.,]\d+)?)\s*(кг|г)\b',title.lower())
        if not 0<price<100000 or not weight:continue
        grams=round(float(weight[1].replace(',','.'))*(1000 if weight[2]=='кг' else 1),2)
        if grams<=0:continue
        source=urljoin(url,product[1])
        found.append({'id':store+'-shop-'+hashlib.sha256(source.encode()).hexdigest()[:16],'store':store,'ingredient':food,'name':full,'price':price,'oldPrice':None,'packGrams':grams,'pricePerKg':round(price*1000/grams,2),'sourceUpdated':updated.isoformat(),'source':url,'sourceType':'observed-price','city':'Казань','conditions':'Опубликованная цена Шопоклик для Казани. Срок акции не указан. Уточни цену, карту и наличие в магазине.'})
    return found

def collect_observed(today):
    def shop(pair):
        store,slug=pair;url='https://kazan.shopoclick.ru/magazin/'+slug
        try:
            root=fetch(url)
            links=set(re.findall(r'href="(/magazin/'+re.escape(slug)+r'/[^"/]+)"',root))
        except Exception:return []
        found=[]
        for path in sorted(links):
            category=path.rsplit('/',1)[-1]
            if category not in SHOP_CATEGORIES:continue
            try:found.extend(parse_observed(fetch(urljoin(url,path)),urljoin(url,path),store,today,SHOP_CATEGORIES[category]))
            except Exception:continue
        return found
    with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(shop,SHOP_STORES.items()))
    return {o['id']:o for group in results for o in group}.values()

def collect(output):
    now=datetime.now(timezone.utc);today=now.astimezone(timezone(timedelta(hours=3))).date().isoformat()
    try:
        root=fetch('https://proshoper.ru/kazan/actions/')
        menu=json.loads(re.search(r'<script id="menu-data"[^>]*>(.*?)</script>',root,re.S)[1])
        discovered={s['slug']:urljoin('https://proshoper.ru',s['url']) for s in menu['shops']}
    except Exception as e:
        raise RuntimeError('Catalog index unavailable; previous feed must remain unchanged') from e
    def one(item):
        key,(name,slug,official)=item;url=discovered.get(slug)
        status={'id':key,'name':name,'official':official,'source':url,'status':'unavailable','checkedAt':now.isoformat(),'count':0,'message':'Нет открытого каталога с подтверждёнными ценами для Казани. Это не означает отсутствие магазина или скидок.'}
        if not url:return status,[]
        try:
            body=fetch(url)
            if 'Казань' not in body:raise ValueError('Region not verified')
            found=parse_catalog(body,url,key,today)
            status.update(status='ok' if found else 'no_current_offers',count=len(found),message='Проверен каталог Казани.' if found else 'В источнике нет действующих распознанных предложений на ингредиенты.')
            return status,found
        except Exception as e:
            status.update(status='error',message='Источник временно недоступен. Подтверждённые цены не получены.')
            return status,[]
    with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(one,STORES.items()))
    observed=list(collect_observed(today))
    for status,items in results:
        extra=[o for o in observed if o['store']==status['id']]
        items.extend(extra)
        if extra:status.update(status='ok',count=len(items),message='Цены из каталогов и открытых публикаций Казани; даты указаны у товаров.')
    feed={'schema':1,'city':'Казань','checkedAt':now.isoformat(),'schedule':'Проверка каждые 6 часов, время запуска может сдвигаться на стороне GitHub.','stores':[s for s,_ in results],'offers':[o for _,items in results for o in items]}
    output.parent.mkdir(parents=True,exist_ok=True)
    temporary=output.with_suffix('.tmp');temporary.write_text(json.dumps(feed,ensure_ascii=False,separators=(',',':')),encoding='utf-8');temporary.replace(output)
    print(json.dumps({'stores':len(results),'covered':sum(s['status']=='ok' for s,_ in results),'offers':len(feed['offers']),'checkedAt':feed['checkedAt']}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'source/public/local/kazan-offers.json');args=p.parse_args();collect(args.output)
