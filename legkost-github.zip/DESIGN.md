---
version: alpha
name: "Лёгкость — локальный рацион"
description: "Автономная анкета и личный план питания с тёплой палитрой исходного сайта."
colors:
  primary: "#F0894A"
  background: "#FCF8F2"
  foreground: "#1C1814"
  surface: "#FFFFFF"
  muted: "#6E6358"
  border: "#EFE6D8"
  success: "#267B48"
  danger: "#AE392A"
typography:
  sans:
    fontFamily: "Onest, system-ui, sans-serif"
rounded:
  DEFAULT: "22px"
  sm: "12px"
  md: "14px"
  lg: "24px"
spacing:
  page-max: "1000px"
  quiz-max: "440px"
  page-padding: "24px"
components:
  button:
    minHeight: "46px"
  card:
    padding: "22px"
  dialog:
    maxWidth: "680px"
---

# Локальная Лёгкость

## Kazan prices extension

The basket extension uses existing summary cards, native checkbox/store controls, recipe dialogs and buttons. Comparisons use a semantic 13-row table with one local horizontal scroller, never a clipped page. Confirmed partial costs and missing products have equal visual prominence. Promotion menus use the established preview/apply/cancel/undo behavior. No visual tokens changed.

Approved scope now includes a public Pages edition and Kazan catalog prices. Shared offer cards preserve Onest, warm surfaces, borders and existing tokens. Emphasis belongs to package price, source, chain and dates. The offers section follows recipe instructions; unavailable data must not look like a discount. The deals tab reuses native settings selects, search/clear controls, pagination and toast behavior. No visual tokens changed.

## Overview

### Creative North Star

The public quiz at quiz.legkost-test.online/racion is the visual reference: a narrow warm cream questionnaire, Onest, white rounded cards and an amber-to-coral primary action. The local meal planner extends that identity without pretending its unavailable paid result was inspected.

### Product context and register

One Russian-speaking Windows user, private use on one computer. Product register. The questionnaire preserves the published client interface; the planner is independently implemented. No cloud identity, subscription, live store API or public hosting. Locale ru-RU; calendar weeks start on Monday, dates use the computer's local timezone.

Token ownership: the published quiz retains its downloaded styles. The local planner's canonical runtime tokens are the :root properties in public/local/app.css, mirrored above. The corresponding .button, .card, dialog, .tabs, .field and .shopping-row implement them. accessibility.css owns the shared scrollbar, keyboard focus and reduced-motion baseline across both routes.

## Colors

Cream background, white surfaces and warm hairline borders. Primary actions use the source gradient #FFC56F to #FF8A5C. Darker brown-orange text is used for secondary actions to retain contrast. Success and error include explanatory text. There is one light theme; forced-colors retains native control semantics.

## Typography

Onest uses the copied Cyrillic and Latin source font files. Titles are 24px in the quiz and 32px in the planner, reduced to 27px on narrow screens. Body text is 15px with 1.5 line height. Nutrition and monetary values use ru-RU formatting. No remote font loading.

## Layout

The source quiz is 440px maximum width with 24px inner padding. The planner expands to 1000px for the week, library and shopping list. Below 750px the meal grid becomes a single column and forms stack. Each panel owns document scrolling; dialogs scroll internally. No ancestor clips long settings forms.

## Elevation & Depth

Cards use a 1.5px border and low-opacity source-like shadow. Only dialogs and status messages use strong elevation. Images reserve geometry. Feedback never moves the primary controls.

## Shapes

22px cards, 14px primary controls, 12px smaller controls, 24px dialogs. Pills have compact descriptive text, with no symbolic replacement of a visible source asset.

## Components

### Foundational visual states

Enabled controls have pointer, hover, active and visible focus. Disabled pagination is visibly muted and cannot fire. Loading is an app-owned message; failed recipe loading has an explicit reload action. Empty and no-result states describe a corrective action. Saved changes use the shared status live region.

### Buttons and actions

.button defines solid, secondary, ghost and danger variants. Source questionnaire controls are retained. All newly implemented actions use semantic button elements. Dialog confirmation is reserved for replacing local data from a backup.

### Navigation and data display

Menu, shopping, cooking, recipes and settings are URL-addressable views. Recipe results have explicit pagination of 12 items. Day and week navigation preserve saved weekly plans. Shopping lists contain the finite ingredient set of the current week.

### Forms and overlays

The settings form owns validation and uses novalidate, associated labels, text errors and aria-invalid. Selects are intentionally native: platform popup geometry is accepted. No custom calendar is needed. Modal dialogs use the app-owned HTML dialog element, native focus containment, Escape and explicit focus restoration.

### Iconography

The quiz retains its original published visual assets and glyphs. New planner actions are text labels; no unrelated icon library is introduced. Only recipes whose original public cards had photos use copied matching images. Other recipes are deliberately presented as text cards.

### Motion

Short hover and press feedback. Reduced-motion disables inherited transitions and animation. No decorative ambient motion.

### Content and data visualization

Plain Russian action labels. Calories, macronutrients and ingredient costs are approximate calculations over the bundled data. Source recipe photos and names do not imply possession of the service's private recipe instructions. The local instructions were independently written.

## Do's and Don'ts

- Preserve the source questionnaire's spacing and typographic hierarchy.
- Keep all personal data on loopback and in the browser's local storage.
- Never silently relax exclusions or reduce portions to make an impossible budget appear satisfied.
- Never describe approximate prices as live store quotes, or this edition as a copy of the unavailable private backend.
