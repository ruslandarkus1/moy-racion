import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {compareBasket,comparableOffer,createPromotionPlan,promotionWeights,promotionCoverage} from '../public/local/economy.js';
import {DEFAULTS,buildPlan,validatePlan,dayNutrition} from '../public/local/engine.js';
import {packCost} from '../public/local/offers.js';
const now=new Date('2026-11-24T15:00:00Z');
const data=JSON.parse(fs.readFileSync(new URL('../public/local/foods.json',import.meta.url),'utf8'));
const make=(id,store,ingredient,price,packGrams,name=ingredient)=>({id,store,ingredient,price,packGrams,name,oldPrice:price*2,city:'Казань',starts:'2026-11-24',ends:'2026-11-30',source:'https://proshoper.ru/kazan/actions/test/#'+id});
const feed=offers=>({schema:1,city:'Казань',checkedAt:'2026-11-24T14:00:00Z',offers});
test('whole-package selection can prefer higher unit price with less package expense',()=>{
 const result=compareBasket([{id:'rice',grams:600}],feed([make('large','mag','rice',90,1000),make('small','mag','rice',50,600)]),['mag'],{},now);
 assert.equal(result.total,50);assert.equal(result.mixed[0].choice.offer.id,'small');assert.equal(result.complete,true);
 assert.equal(packCost(make('a','mag','rice',10,400),400.00000000001).packs,1);
});
test('incomplete stores are compared only on their common products',()=>{
 const result=compareBasket([{id:'rice',grams:1000},{id:'carrot',grams:500},{id:'onion',grams:200}],feed([make('r1','mag','rice',90,1000),make('c1','mag','carrot',70,1000),make('r2','p5','rice',100,1000)]),['mag','p5','sam'],{},now);
 assert.equal(result.complete,false);assert.equal(result.covered,2);assert.equal(result.total,160);assert.deepEqual(result.missing.map(i=>i.id),['onion']);
 assert.deepEqual(result.common.map(i=>i.id),['rice']);assert.equal(result.commonSavings,0);assert.equal(result.rows.find(r=>r.store==='p5').commonTotal,100);assert.equal(result.rows.find(r=>r.store==='sam').commonTotal,null);
});
test('split savings use exactly the same products and package quantities',()=>{
 const result=compareBasket([{id:'rice',grams:1000},{id:'carrot',grams:500}],feed([make('r1','mag','rice',90,1000),make('c1','mag','carrot',100,1000),make('r2','p5','rice',120,1000),make('c2','p5','carrot',60,500)]),['mag','p5'],{},now);
 assert.equal(result.total,150);assert.equal(result.commonMixed,150);assert.equal(result.commonSavings,30);assert.equal(result.common.length,2);
});
test('expired feeds, wrong units, wrong fat and bone-in poultry do not enter automatic comparison',()=>{
 assert.equal(comparableOffer(make('a','mag','chicken',100,1000,'Грудка цыпленка без кожи')),false);
 assert.equal(comparableOffer(make('b','mag','milk',100,900,'Молоко 3.2% 900г')),false);
 assert.equal(comparableOffer(make('c','mag','milk',100,900,'Молоко 2.5% 900г')),true);
 assert.equal(comparableOffer(make('d','mag','yogurt',100,900,'Йогурт натуральный'),{allergies:['nuts']}),false);
 const expired=compareBasket([{id:'rice',grams:1000}],{...feed([make('a','mag','rice',50,1000)]),checkedAt:'2026-11-20T00:00:00Z'},['mag'],{},now);
 assert.equal(expired.covered,0);assert.equal(expired.commonSavings,null);assert.equal(expired.complete,false);
 assert.throws(()=>compareBasket([{id:'rice',grams:-1}],feed([]),['mag'],{},now));
});
test('promotion planning preserves restrictions, repeats, portions and nutrition',()=>{
 const offers=feed([make('rice','mag','rice',40,1000),make('carrot','mag','carrot',30,1000),make('potato','mag','potato',30,1000),make('lentils','mag','lentils',50,1000)]);
 for(const profile of [{...DEFAULTS,diet:'vegan',allergies:['nuts','eggs','lact']},{...DEFAULTS,allergies:['fish','lact'],dislikes:['mush'],stopFoods:['лук']},{...DEFAULTS,adults:3,kids:[6],famMeals:['fam-lunch','fam-dinner']}]){
  const original=buildPlan(profile,data,'2026-11-23');const before=JSON.stringify(original);
  const {plan}=createPromotionPlan(profile,data,'2026-11-23',1,{},offers,['mag'],now);
  assert.equal(validatePlan(plan,data),true);assert.equal(JSON.stringify(original),before);
  for(let i=0;i<7;i++)assert.ok(Math.abs(dayNutrition(plan.days[i],data,plan.profile).kcal-dayNutrition(original.days[i],data,original.profile).kcal)<.001);
  assert.ok(promotionCoverage(plan,data,promotionWeights(data,offers,['mag'],profile,now)).slots>0);
 }
 assert.throws(()=>createPromotionPlan(DEFAULTS,data,'2026-11-23',1,{},feed([]),['mag'],now),/Нет свежих/);
});
