import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {DEFAULTS,normalizeProfile,getNutrition,compatible,buildPlan,shoppingList,recipeNutrition,replaceSlot,portions,weekKey,cookingDay,dayNutrition,validatePlan,isDateKey} from '../public/local/engine.js';
const data=JSON.parse(await readFile(new URL('../public/local/foods.json',import.meta.url),'utf8'));
const profile=overrides=>normalizeProfile({...DEFAULTS,...overrides});
const near=(a,b)=>assert.ok(Math.abs(a-b)<.0001,`${a} differs from ${b}`);
test('library has over 250 unique complete recipes with valid ingredient references',()=>{
 assert.ok(data.recipes.length>=250);assert.equal(new Set(data.recipes.map(x=>x.id)).size,data.recipes.length);assert.equal(new Set(data.recipes.map(x=>x.name)).size,data.recipes.length);
 for(const r of data.recipes){assert.ok(r.steps.length>=2);for(const i of r.ingredients){assert.ok(data.ingredients[i.id]);assert.ok(i.grams>0)}for(const value of Object.values(r.nutrition))assert.ok(Number.isFinite(value)&&value>=0);near(recipeNutrition(r,data).kcal,Math.round(r.nutrition.kcal*100)/100);}
});
test('calculation matches published questionnaire factors and manual target',()=>{
 const p=profile();const expected=10*Math.round(((655+9.6*p.weight+1.8*p.height-4.7*p.age)*1.46-350)/10);
 assert.equal(getNutrition(p).kcal,expected);assert.equal(getNutrition(profile({manualKcal:1900})).kcal,1900);
 assert.ok(getNutrition(profile({sex:'m'})).kcal>expected);
});
test('all four diets produce seven days and three meals without forbidden ingredients',()=>{
 for(const diet of ['omni','pesc','veget','vegan']){
  const p=profile({diet});const plan=buildPlan(p,data,'2026-11-23');assert.equal(plan.days.length,7);assert.equal(plan.days.flatMap(d=>d.slots).length,21);
  for(const d of plan.days)for(const s of d.slots){const r=data.recipes.find(r=>r.id===s.recipeId);assert.ok(compatible(r,p,data));near(s.totalScale,portions(p,s.meal,s.scale));}
 }
});
test('each allergen and dislike is strictly excluded, including combinations',()=>{
 const tags=['nuts','glut','lact','pnut','sea','eggs','hony','soy','fish','citr','ses','mush','onio','garl','oliv','eggp','cila','spic','sugr','pork','beef','caff','tofu'];
 for(const tag of tags){const p=profile({allergies:[tag],dislikes:[tag]});for(const r of data.recipes.filter(r=>compatible(r,p,data)))assert.ok(r.ingredients.every(i=>!data.ingredients[i.id].tags.includes(tag)));}
 const p=profile({diet:'vegan',allergies:['glut','soy','nuts','ses'],dislikes:['onio','garl']});const plan=buildPlan(p,data,'2026-11-23');for(const item of shoppingList(plan,data))assert.ok(!item.tags.some(t=>p.allergies.includes(t)||p.dislikes.includes(t)));
});
test('custom product exclusion checks actual ingredients',()=>{const p=profile({stopFoods:['морковь','банан']});for(const r of data.recipes.filter(r=>compatible(r,p,data)))assert.ok(!r.ingredients.some(i=>['carrot','banana'].includes(i.id)));});
test('kitchen is a hard condition; cold dishes work without appliances',()=>{const p=profile({kitchen:[]});for(const r of data.recipes.filter(r=>compatible(r,p,data)))assert.equal(r.methods.length,0);assert.equal(compatible(data.recipes.find(r=>r.name==='Крем-суп из цветной капусты'),profile({kitchen:['blend']}),data),false);});
test('weekly repeat limit is global across lunch and dinner',()=>{
 for(const repeat of [1,2,3]){const plan=buildPlan(profile({repeat}),data,'2026-11-23');const counts={};for(const slot of plan.days.flatMap(d=>d.slots))counts[slot.recipeId]=(counts[slot.recipeId]??0)+1;assert.ok(Object.values(counts).every(n=>n<=repeat));}
});
test('family ingredients include adults and child portions but personal nutrients stay separate',()=>{
 const p=profile({adults:3,kids:[5,10],famMeals:['fam-dinner']});const plan=buildPlan(p,data,'2026-11-23');for(const day of plan.days)for(const s of day.slots)near(s.totalScale,s.meal==='dinner'?s.scale*3+1.2:s.scale);
 const totals={};for(const day of plan.days)for(const s of day.slots)for(const i of data.recipes.find(r=>r.id===s.recipeId).ingredients)totals[i.id]=(totals[i.id]??0)+i.grams*s.totalScale;
 for(const item of shoppingList(plan,data))near(item.grams,totals[item.id]);
});
test('full selected meals meet target calories without counting family portions as personal',()=>{const p=profile(),plan=buildPlan(p,data,'2026-11-23');for(const d of plan.days)near(dayNutrition(d,data,p).kcal,getNutrition(p).kcal);});
test('budget is not met by shrinking nutrition; impossible budget remains visibly over',()=>{const p=profile({budget:1}),plan=buildPlan(p,data,'2026-11-23');assert.ok(plan.total>1);for(const d of plan.days)near(dayNutrition(d,data,p).kcal,getNutrition(p).kcal);});
test('manual prices affect exact shopping totals and zero price is respected',()=>{const p=profile(),plan=buildPlan(p,data,'2026-11-23');const prices=Object.fromEntries(Object.keys(data.ingredients).map(key=>[key,0]));assert.equal(shoppingList(plan,data,prices).reduce((s,x)=>s+x.cost,0),0);});
test('drinks are included in personal nutrition and purchases and conflicts are rejected',()=>{
 const p=profile({coffee:'yes',drinks:['latte'],cups:2,spoons:1}),plan=buildPlan(p,data,'2026-11-23');for(const d of plan.days)near(dayNutrition(d,data,p).kcal,getNutrition(p).kcal);const items=shoppingList(plan,data);assert.ok(items.find(x=>x.id==='milk').grams>=3500);assert.ok(items.find(x=>x.id==='coffee').grams>=140);assert.ok(items.find(x=>x.id==='sugar').grams>=70);
 assert.throws(()=>buildPlan(profile({diet:'vegan',coffee:'yes',drinks:['latte']}),data),/молоком/);assert.throws(()=>buildPlan(profile({allergies:['lact'],coffee:'yes',drinks:['capp']}),data),/молоком/);assert.throws(()=>buildPlan(profile({dislikes:['sugr'],coffee:'yes',spoons:1}),data),/Сахар/);
});
test('replacement preserves personal calorie allocation, constraints and updates purchases',()=>{
 const p=profile(),plan=buildPlan(p,data,'2026-11-23'),slot=plan.days[0].slots[0],old=recipeNutrition(data.recipes.find(r=>r.id===slot.recipeId),data,slot.scale).kcal;
 const candidate=data.recipes.find(r=>r.id!==slot.recipeId&&r.meals.includes(slot.meal)&&compatible(r,p,data)&&!plan.days.flatMap(d=>d.slots).some(s=>s.recipeId===r.id));assert.ok(candidate);
 replaceSlot(plan,data,0,slot.meal,candidate.id);near(recipeNutrition(candidate,data,slot.scale).kcal,old);near(plan.total,shoppingList(plan,data).reduce((s,x)=>s+x.cost,0));
});
test('cook dates and fresh handling are consistent; distant prepared portions are frozen',()=>{const p=profile(),plan=buildPlan(p,data,'2026-11-23');for(const d of plan.days)for(const s of d.slots){assert.ok(s.cookOn<=d.day);if(s.storage==='fresh')assert.equal(s.cookOn,d.day);else{assert.equal(s.cookOn,cookingDay(p,d.day));assert.equal(s.storage,d.day-s.cookOn>=2?'freeze':'fridge')}}});
test('empty results and invalid nutrition produce actionable errors without relaxing constraints',()=>{assert.throws(()=>buildPlan(profile({meals:[],famMeals:[]}),data),/приём пищи/);assert.throws(()=>buildPlan(profile({diet:'vegan',kitchen:[]}),data),/нет рецептов/);assert.throws(()=>buildPlan(profile({manualKcal:500}),data),/1200/);});
test('date and profile boundary handling',()=>{assert.equal(weekKey(new Date('2026-11-29T12:00:00')),'2026-11-23');const p=normalizeProfile({adults:NaN,age:-50,life:100,kids:[-1,'x',3,19],diet:'unknown',allergies:['nuts','__proto__']});assert.equal(p.adults,2);assert.equal(p.age,14);assert.equal(p.life,4);assert.deepEqual(p.kids,[3]);assert.deepEqual(p.allergies,['nuts']);});
test('saved plan and backup validation rejects damaged, inconsistent or incompatible data',()=>{
 const plan=buildPlan(profile(),data,'2026-11-23');assert.equal(validatePlan(plan,data),true);
 for(const mutate of [p=>p.days[0].slots[0].totalScale=100,p=>p.days[0].slots[0].recipeId='unknown',p=>p.days[1].date='2026-02-30',p=>p.checked={},p=>p.days[0].slots.push(p.days[0].slots[0]),p=>p.profile.diet='vegan']){
  const damaged=structuredClone(plan);mutate(damaged);assert.equal(validatePlan(damaged,data),false);
 }
 assert.equal(validatePlan(null,data),false);assert.equal(validatePlan({days:[null]},data),false);
});
test('calendar keys reject impossible dates rather than silently normalizing them',()=>{assert.equal(isDateKey('2026-02-30'),false);assert.equal(isDateKey('2026-13-01'),false);assert.equal(isDateKey('2024-02-29'),true);assert.equal(isDateKey('2026-11-24'),true);});
