import test from 'node:test';
import assert from 'node:assert/strict';
import {currentOffers,forIngredients,packCost,safeSource} from '../public/local/offers.js';
const now=new Date('2026-11-24T20:59:00Z');
const offer={id:'a',store:'mag',ingredient:'oats',city:'Казань',price:79.99,packGrams:400,starts:'2026-11-24',ends:'2026-11-24',source:'https://proshoper.ru/kazan/actions/magnit-magazin/#id_product_1'};
const feed={schema:1,city:'Казань',checkedAt:'2026-11-24T15:00:00Z',offers:[offer]};
test('catalog expires at midnight in Kazan rather than browser timezone',()=>{
 assert.equal(currentOffers(feed,now).length,1);
 assert.equal(currentOffers(feed,new Date('2026-11-24T21:00:00Z')).length,0);
});
test('stale, future timestamps, invalid price, another city and unsafe links cannot become current offers',()=>{
 for(const changed of [{checkedAt:'2026-11-22T00:00:00Z'},{checkedAt:'2026-11-25T00:00:00Z'},{city:'Москва'}])assert.equal(currentOffers({...feed,...changed},now).length,0);
 for(const changed of [{price:-1},{price:Infinity},{price:NaN},{city:'Москва'},{source:'javascript:alert(1)'},{source:'https://proshoper.ru.evil.example/'}])assert.equal(currentOffers({...feed,offers:[{...offer,...changed}]},now).length,0);
 assert.equal(safeSource('https://kazan.proshoper.ru/actions/'),true);
});
test('recipe matches only ingredient ids and rounds shopping up to whole packs',()=>{
 assert.equal(forIngredients(feed,['milk'],now).length,0);
 assert.equal(forIngredients(feed,['oats'],now).length,1);
 assert.deepEqual(packCost(offer,401),{packs:2,cost:159.98});
 assert.equal(packCost({...offer,packGrams:null},500),null);
});
