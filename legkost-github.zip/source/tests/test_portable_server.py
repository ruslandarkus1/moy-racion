"""HTTP integration checks for the exact server shipped for Android/Termux."""
import http.client
import importlib.util
import json
from pathlib import Path
import threading
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("portable_server", ROOT / "server.py")
portable = importlib.util.module_from_spec(spec)
spec.loader.exec_module(portable)


class PortableServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = portable.create_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)

    def request(self, path, method="GET", headers=None, body=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        try:
            connection.request(method, path, body=body, headers=headers or {})
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            connection.close()

    def test_loopback_only_health(self):
        self.assertEqual(self.server.server_address[0], "127.0.0.1")
        status, _, body = self.request("/health")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["runtime"], "python")

    def test_every_public_file_matches_source_bytes(self):
        for file in (ROOT / "public").rglob("*"):
            if not file.is_file():
                continue
            path = "/" + file.relative_to(ROOT / "public").as_posix()
            with self.subTest(path=path):
                status, _, body = self.request(path)
                self.assertEqual(status, 200)
                self.assertEqual(body, file.read_bytes())

    def test_questionnaire_aliases_and_menu(self):
        for path in ["/", "/racion", "/racion/?restart=1"]:
            with self.subTest(path=path):
                status, headers, body = self.request(path)
                self.assertEqual(status, 200)
                self.assertEqual(body, (ROOT / "public/index.html").read_bytes())
                self.assertTrue(headers["Content-Type"].startswith("text/html"))
        self.assertEqual(self.request("/menu.html?tab=recipes")[0], 200)

    def test_local_configuration_and_no_paid_status(self):
        status, _, body = self.request("/api/ab-config?surface=racion")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body), json.loads((ROOT / "config/ab-config.json").read_text(encoding="utf-8")))
        status, _, body = self.request("/api/session")
        self.assertEqual(status, 200)
        self.assertFalse(json.loads(body)["access"]["paid"])
        self.assertEqual(self.request("/api/finik/create-payment-ab", "POST")[0], 410)

    def test_utf8_posts_are_consumed_without_persisting_personal_data(self):
        body = json.dumps({"state": {"stopFoods": ["морковь"]}}, ensure_ascii=False).encode()
        status, _, reply = self.request("/api/session", "POST", {"Content-Type": "application/json; charset=utf-8"}, body)
        self.assertEqual(status, 200)
        self.assertTrue(json.loads(reply)["ok"])

    def test_mime_and_head(self):
        status, headers, body = self.request("/local/app.js", "HEAD")
        self.assertEqual(status, 200)
        self.assertEqual(body, b"")
        self.assertIn("javascript", headers["Content-Type"])
        self.assertEqual(int(headers["Content-Length"]), (ROOT / "public/local/app.js").stat().st_size)

    def test_security_headers(self):
        _, headers, _ = self.request("/menu.html")
        self.assertIn("connect-src 'self'", headers["Content-Security-Policy"])
        self.assertIn("frame-src 'none'", headers["Content-Security-Policy"])
        self.assertEqual(headers["Cache-Control"], "no-store")

    def test_host_origin_and_traversal(self):
        self.assertEqual(self.request("/health", headers={"Host": "external.example"})[0], 403)
        self.assertEqual(self.request("/api/session", headers={"Origin": "https://external.example"})[0], 403)
        for path in ["/%2e%2e/server.py", "/%2e%2e%5cserver.py", "/../config/ab-config.json"]:
            with self.subTest(path=path):
                self.assertEqual(self.request(path)[0], 403)
        self.assertEqual(self.request("/server.py")[0], 404)

    def test_no_static_writes_or_oversize_requests(self):
        self.assertEqual(self.request("/menu.html", "POST", body=b"test")[0], 405)
        self.assertEqual(self.request("/api/session", "POST", {"Content-Length": "300000"})[0], 413)
        self.assertEqual(self.request("/api/session", "POST", {"Content-Length": "invalid"})[0], 400)

    def test_stop_requires_correct_token(self):
        self.assertEqual(self.request("/__stop", "POST")[0], 403)
        self.assertEqual(self.request("/__stop", "POST", {"X-Legkost-Control": "é"})[0], 403)
        self.assertEqual(self.request("/__stop", "GET", {"X-Legkost-Control": self.server.control_token})[0], 403)
        self.assertEqual(self.request("/health")[0], 200)

    def test_authorized_stop_of_isolated_server(self):
        server = portable.create_server(0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            status, result = portable.local_request(server.server_port, "/__stop", "POST", {"X-Legkost-Control": server.control_token})
            self.assertEqual(status, 200)
            self.assertTrue(result["stopped"])
            thread.join(timeout=3)
            self.assertFalse(thread.is_alive())
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
