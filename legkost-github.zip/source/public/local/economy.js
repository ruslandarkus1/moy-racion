import {currentOffers,packCost} from './offers.js';
import {buildPlan,shoppingList} from './engine.js';

// Conservative matches for automatic comparisons. Exact packaging/composition still needs review.
export function comparableOffer(o,profile={}){
  if(!Number.isFinite(o.packGrams)||o.packGrams<=0||!Number.isFinite(o.price)||o.price<=0)return false;
  const name=String(o.name).toLowerCase().replace(/ё/g,'е');
  if(/сгущен|безлактоз|детск|сахаром|топлен|маринован|солен|копчен|полуфабрикат|паниров|пастеризован.*картоф|картоф.*пастеризован/.test(name))return false;
  if(o.ingredient==='chicken'&&!/филе/.test(name))return false;
  const fats={milk:2.5,cream:10,curd:5,sour:15,kefir:2.5,butter:82.5};
  if(o.ingredient in fats){const fat=name.match(/(\d+(?:[.,]\d+)?)\s*%/);if(!fat||Number(fat[1].replace(',','.'))!==fats[o.ingredient])return false;}
  // Prepared branded foods cannot be matched automatically under allergy/strict diet constraints.
  if((profile.allergies?.length||['vegan','veget','pesc'].includes(profile.diet))&&['bread','yogurt','cheese','mozzarella','feta','tuna','beans','tofu','soySauce'].includes(o.ingredient))return false;
  return true;
}
export function eligibleOffers(feed,stores,profile={},now){const selected=new Set(stores);return currentOffers(feed,now).filter(o=>selected.has(o.store)&&comparableOffer(o,profile));}
function cheapest(item,offers){return offers.filter(o=>o.ingredient===item.id).map(offer=>({offer,...packCost(offer,item.grams)})).sort((a,b)=>a.cost-b.cost||a.packs*a.offer.packGrams-b.packs*b.offer.packGrams||a.offer.id.localeCompare(b.offer.id))[0]??null;}
export function compareBasket(items,feed,stores,profile={},now){
  if(!Array.isArray(items)||items.some(i=>!i||typeof i.id!=='string'||!Number.isFinite(i.grams)||i.grams<=0)||new Set(items.map(i=>i.id)).size!==items.length)throw new Error('Некорректное количество продуктов в корзине. Составь меню заново.');
  const offers=eligibleOffers(feed,stores,profile,now);
  const rows=[...new Set(stores)].map(store=>{const available=offers.filter(o=>o.store===store);const lines=items.map(item=>({item,choice:cheapest(item,available)}));const matched=lines.filter(l=>l.choice);return {store,lines,covered:matched.length,total:Math.round(matched.reduce((s,l)=>s+l.choice.cost,0)*100)/100,complete:items.length>0&&matched.length===items.length};});
  const active=rows.filter(r=>r.covered>0);
  const common=items.filter(item=>active.length>=2&&active.every(r=>r.lines.some(l=>l.item.id===item.id&&l.choice)));
  const commonIds=new Set(common.map(x=>x.id));
  for(const row of rows)row.commonTotal=active.includes(row)&&common.length?Math.round(row.lines.filter(l=>commonIds.has(l.item.id)).reduce((s,l)=>s+l.choice.cost,0)*100)/100:null;
  const mixed=items.map(item=>({item,choice:cheapest(item,offers)}));
  const matched=mixed.filter(l=>l.choice),missing=mixed.filter(l=>!l.choice).map(l=>l.item);
  const total=Math.round(matched.reduce((s,l)=>s+l.choice.cost,0)*100)/100;
  const commonMixed=Math.round(matched.filter(l=>commonIds.has(l.item.id)).reduce((s,l)=>s+l.choice.cost,0)*100)/100;
  const baseline=common.length?Math.min(...active.map(r=>r.commonTotal)):null;
  return {rows,activeStores:active.length,common,commonMixed,commonSavings:baseline===null?null:Math.max(0,Math.round((baseline-commonMixed)*100)/100),mixed,missing,covered:matched.length,total,complete:items.length>0&&missing.length===0};
}
export function promotionWeights(data,feed,stores,profile={},now){
  const offers=eligibleOffers(feed,stores,profile,now).filter(o=>Number.isFinite(o.oldPrice)&&o.oldPrice>o.price);
  const discounts=new Map();for(const o of offers)discounts.set(o.ingredient,Math.max(discounts.get(o.ingredient)??0,1-o.price/o.oldPrice));
  const weights={};for(const recipe of data.recipes){const grams=recipe.ingredients.reduce((s,i)=>s+i.grams,0);const weight=grams?recipe.ingredients.reduce((s,i)=>s+i.grams*(discounts.get(i.id)??0),0)/grams:0;if(weight>0)weights[recipe.id]=weight;}
  return weights;
}
export function createPromotionPlan(profile,data,week,nonce,prices,feed,stores,now){
  const weights=promotionWeights(data,feed,stores,profile,now);
  if(!Object.keys(weights).length)throw new Error('Нет свежих сопоставимых акций для подбора меню. Обнови предложения или выбери другие магазины.');
  const plan=buildPlan(profile,data,week,nonce,prices,{promotionWeights:weights});
  const score=promotionCoverage(plan,data,weights);
  if(!score.slots)throw new Error('Нет подходящих блюд с акциями при твоих ограничениях. Текущее меню сохранено.');
  return {plan,coverage:score,basket:compareBasket(shoppingList(plan,data,prices),feed,stores,profile,now)};
}
export function promotionCoverage(plan,data,weights){const slots=plan.days.flatMap(d=>d.slots);return {slots:slots.filter(s=>weights[s.recipeId]>0).length,total:slots.length,score:slots.reduce((sum,s)=>sum+(weights[s.recipeId]??0),0)/Math.max(1,slots.length)};}
